# OoTMM Randomizer Item Tracker for EmoTracker

###### Version 2.1.0

<br />

## Usage

- Install [EmoTracker](https://emotracker.net/download/).
- Download the current tracker pack from EmoTracker's package manager (cloud symbol) in the "Others" section at the bottom.
- Open EmoTracker and select "OoTMM Randomizer Item Tracker" under `"Installed Packages" -> "Other"` in the settings menu.
- Choose your preferred variant (currently either `"Shared Items"` or `"Shared Items w/ Souls"`).

The gear in the top right of the tracker will open the settings menu, which allows you to configure, based on your settings, which items you want the tracker to keep track of and which ones you want hidden.

<br />

## Settings

The settings are split into multiple tabs. This list aims to document and explain each setting.

### Quest Settings

---

![Triforce Quest](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/triforce_quest.png?raw=true)

If this setting is enabled, the triforce piece item will be available in the tracker and automatically set to a max count of 3.


![Triforce Pieces](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/triforce_pieces.png?raw=true)

If "Triforce Quest" is enabled, this setting will not be interactable.
You can increment the amount of triforce pieces you need to complete your seed by left clicking, or decrement the amount by right clicking. If this is greater than 0, the triforce piece item will be available in the tracker.

---

![Red Coins](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/red_coins.png?raw=true)

If this setting is enabled, you will be able to track Red Coins, added items that can be used for special conditions.


![Yellow Coins](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/yellow_coins.png?raw=true)

If this setting is enabled, you will be able to track Yellow Coins, added items that can be used for special conditions.


![Green Coins](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/green_coins.png?raw=true)

If this setting is enabled, you will be able to track Green Coins, added items that can be used for special conditions.


![Blue Coins](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/blue_coins.png?raw=true)

If this setting is enabled, you will be able to track Blue Coins, added items that can be used for special conditions.

<br />

### Dungeon Settings

---

![OoT Dungeons: Vanilla](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/oot_dungeons_vanilla.png?raw=true)![OoT Dungeons: Master Quest](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/oot_dungeons_master_quest.png?raw=true)![OoT Dungeons: Mixed](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/oot_dungeons_mix.png?raw=true)

This setting has multiple states. If it is set to "Vanilla" or "Master Quest", all OoT Dungeons items available to track will be updated accordingly. This affects both small key counts and sets of silver rupees. If it is set to "Mixed", you can configure each of the OoT Dungeons to either be Vanilla or Master Quest whenever you gain that knowledge, just left/right-click on the label of the dungeon in question.


![Keysanity](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/keysanity.png?raw=true)

If this setting is enabled, you can track all 8 Fire Temple keys that exist (if Fire Temple is not master quest). If keys are kept to their own dungeon, one of them is removed and a door is unlocked. This setting is hidden if the above setting is set to "Master Quest", as it is unnecessary.


---

![Dungeon Maps and Compasses](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/dungeon_maps_and_compasses.png?raw=true)

If this setting is enabled, you will be able to track the Maps and Compasses for each dungeon that has them.


![Dungeon Small Keys](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/dungeon_small_keys.png?raw=true)

If this setting is enabled, you will be able to track the Small Keys for each dungeon that has them. How many each dungeon has differs between vanilla and master quest, as well as your keysanity settings.


![Silver Rupees](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/silver_rupees.png?raw=true)

If this setting is enabled, you will be able to track the Silver Rupees that appear in sets in many of the dungeons. Which dungeons have them, and how many sets exist in each dungeon differs between vanilla and master quest.


![Dungeon Stray Fairies](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/dungeon_stray_fairies.png?raw=true)

If this setting is enabled, you will be able to track the Stray Fairies for each of the four major Majora's Mask dungeons.


![Dungeon Boss Keys](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/dungeon_boss_keys.png?raw=true)

If this setting is enabled, you will be able to track the Boss Keys for each dungeon that has one.


![Ganon Boss Key](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/ganon_boss_key.png?raw=true)

If this setting is enabled, you will be able to track the boss key for Ganon's Castle.

---

![Thieves' Hideout Keys](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/thieves_hideout_keys.png?raw=true)

If this setting is enabled, you will be able to track the 4 small keys for Thieves' Hideout.


![Treasure Chest Game Keys](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/treasure_chest_game_keys.png?raw=true)

If this setting is enabled, you will be able to track the 6 small keys for the Treasure Chest Game.


![Town Stray Fairy](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/town_stray_fairy.png?raw=true)

If this setting is enabled, you will be able to track the Town Stray Fairy.

---

![Skeleton Key](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/skeleton_key.png?raw=true)

If this setting is enabled, you will be able to track the Skeleton Key, an added item that unlocks every small key door in both games.


![Magical Rupee](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/magical_rupee.png?raw=true)

If this setting is enabled, you will be able to track the Magical Rupee, an added item that solves every silver rupee puzzle.


![Transcendent Fairy](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/transcendent_fairy.png?raw=true)

If this setting is enabled, you will be able to track the Transcendent Fairy, an added item that counts for every stray fairy.

<br />

### Item Settings

---

![Max Wallet: Giant's](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/max_wallet_giant.png?raw=true)![Max Wallet: Colossal](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/max_wallet_colossal.png?raw=true)![Max Wallet: Bottomless](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/max_wallet_bottomless.png?raw=true)

This setting sets the max wallet size you can track.


![Progressive Knife + Biggoron](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/progressive_knife_and_biggoron.png?raw=true)

If this setting is enabled, the Biggoron Sword on the tracker, instead of being a simple toggle, will cycle through the Giant's Knife, the Broken Giant's Knife, then the Biggoron Sword.

---


![Goron Lullaby: Progressive](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/progressive_lullaby.png?raw=true)![Goron Lullaby: Full Only](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/full_lullaby_only.png?raw=true)

If this setting is set to "Progressive", the tracker will recognize that there are two progressive items you must obtain to get the Goron's Lullaby. If it's set to "Full Only", one click will track the full Goron's Lullaby. This setting synergizes with Note Shuffle (see below).


![Scarecrow Songs](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/scarecrow_songs.png?raw=true)

If this setting is enabled, you will be able to track both games' Scarecrow Songs.


![Note Shuffle](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/note_shuffle.png?raw=true)

If this setting is enabled, each song is split into its individual notes. You will have to track each song one note at a time, until you have the full song. If the above Goron Lullaby setting is set to "Progressive", you will get the Lullaby Intro after the first 6 notes of the song, and the full Goron Lullaby after the remaining two.


![Shuffle A+C-Buttons](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/shuffle_c_buttons.png?raw=true)

If this setting is enabled, you will be able to track the A and C-Buttons needed to play ocarina songs.

---

![Bombchus: Free/First Pack](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/bombchus_free_first_pack.png?raw=true)![Bombchus: Bomb Bag](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/bombchus_bomb_bag.png?raw=true)![Bombchus: Bombchu Bags](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/bombchus_bombchu_bags.png?raw=true)

If this setting is set to "Free/First Pack", the tracker will treat bombchus like a simple toggle: have you got them or not? If it's set to "Bomb Bag", you will not be able to toggle the bombchus yourself, instead they are tracked automatically if you have a bomb bag. If it's set to "Bombchu Bags", bombchus will act progressively like bombs when tracking, rather than as a simple toggle.


![Bronze Scale](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/bronze_scale.png?raw=true)

If this setting is enabled, the scale will have a trackable "Bronze" variant in addition to its usual "Silver" and "Golden" variants. The bronze scale is required to swim in water at all.


![Clocks](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/clocks.png?raw=true)

If this setting is enabled, you will be able to track the Clocks you've obtained, if you are using the "Clocks as Items" setting.

---

![Skulltula Tokens: Gold](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/skulltulas_gold.png?raw=true)![Skulltula Tokens: MM Only](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/skulltulas_mm_only.png?raw=true)![Skulltula Tokens: All](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/skulltulas_all.png?raw=true)

This setting determines whether any skulltula tokens should be trackable. If it's set to "Gold", then only Ocarina of Time's Gold Skulltula Tokens will be trackable. If it's set to "MM Only", then only Majora's Mask's Swamp and Ocean Skulltula Tokens will be trackable. If it's set to "All", then all three types of Skulltula Tokens will be trackable. It also, of course, can be set to "Off", as is the default.


![Tingle Maps](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/tingle_maps.png?raw=true)

If this setting is enabled, you will be able to track the 6 Tingle Maps.


![Owl Statues](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/owl_statues.png?raw=true)

If this setting is enabled, you will be able to track which of the 10 Owl Statues you have unlocked, which could be randomized.

<br />

### Misc. Settings

---

![Use OoT Sprites](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/use_oot_sprites.png?raw=true)![Use MM Sprites](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/use_mm_sprites.png?raw=true)

This setting is purely cosmetic. Since there are many items that can be shared between games that have different appearances between games (i.e. Mirror Shield, Hero's Bow, Longshot, etc.), this setting allows you to toggle between which the tracker should use.

---

![Pre-Planted Beans (OoT)](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/pre-planted_beans_oot.png?raw=true)

If this setting is enabled, Ocarina of Time's Magic Beans will be hidden from the tracker.


![Random Bottle Contents](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/random_bottle_contents.png?raw=true)

If this setting is enabled, the four less important bottles will not show their default contents, and you may set their contents yourself if you so wish.

---

![Open Kakariko Gate](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/open_kakariko_gate.png?raw=true)

If this setting is enabled, Zelda's Letter will be hidden from the tracker.


![Skip Child Zelda](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/skip_child_zelda.png?raw=true)

If this setting is enabled, the Chicken will be hidden from the tracker.


![Eggs](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/eggs.png?raw=true)

If this setting is enabled, you will be able to track the 2 Eggs (Weird and Pocket).

<br />

### Souls Settings ("Shared Items w/ Souls" variant ONLY)

---

![Label Souls by Game](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/souls/label_souls_by_game.png?raw=true)

If this setting is enabled, a small label of "OoT" or "MM" will be added to all souls that are exclusive to one game (aka all souls that aren't shared).

---

![Boss Souls](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/souls/boss.png?raw=true)

If this setting is enabled, you will be able to track all of the Boss Souls.


![Enemey Souls](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/souls/enemy.png?raw=true)

If this setting is enabled, you will be able to track all of the Enemy Souls.


![NPC Souls](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/souls/npc.png?raw=true)

If this setting is enabled, you will be able to track all of the NPC Souls.


![Animal Souls](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/souls/animal.png?raw=true)

If this setting is enabled, you will be able to track all of the Animal Souls.


![Misc. Souls](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/souls/misc.png?raw=true)

If this setting is enabled, you will be able to track both of the Misc. Souls.

<br />

### Key Rings

---

![Key Rings: Off](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/key_rings/off.png?raw=true)![Key Rings: Some](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/key_rings/some.png?raw=true)![Key Rings: All](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/key_rings/all.png?raw=true)

This setting quickly modifies all other settings on this tab. If this is set to "Off", all other options will be disabled and uninteractable. If this is set to "Some", all of the options will be freely modifiable. If this is set to "All", all of the options will be forcably turned on and uninteractable.

If you want all but one key ring active, you can set this to "All", then set it to "Some" to save you the work of manually enabling almost every key ring.

---

![Forest Temple](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/key_rings/forest_temple.png?raw=true)

Whether or not the Forest Temple keys are on a key ring.


![Fire Temple](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/key_rings/fire_temple.png?raw=true)

Whether or not the Fire Temple keys are on a key ring.


![Water Temple](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/key_rings/water_temple.png?raw=true)

Whether or not the Water Temple keys are on a key ring.


![Spirit Temple](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/key_rings/spirit_temple.png?raw=true)

Whether or not the Spirit Temple keys are on a key ring.


![Shadow Temple](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/key_rings/shadow_temple.png?raw=true)

Whether or not the Shadow Temple keys are on a key ring.


![Ganon's Castle](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/key_rings/ganons_castle.png?raw=true)

Whether or not the Ganon's Castle keys are on a key ring.

---

![Bottom of the Well](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/key_rings/bottom_of_the_well.png?raw=true)

Whether or not the Bottom of the Well keys are on a key ring.


![Thieves' Hideout](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/key_rings/thieves_hideout.png?raw=true)

Whether or not the Thieves' Hideout keys are on a key ring.


![Gerudo Training Ground](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/key_rings/gerudo_training_ground.png?raw=true)

Whether or not the Gerudo Training Ground keys are on a key ring.


![Treasure Chest Game](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/key_rings/treasure_chest_game.png?raw=true)

Whether or not the Treasure Chest Game keys are on a key ring.

---

![Woodfall Temple](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/key_rings/woodfall_temple.png?raw=true)

Whether or not the Woodfall Temple keys are on a key ring.


![Snowhead Temple](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/key_rings/snowhead_temple.png?raw=true)

Whether or not the Snowhead Temple keys are on a key ring.


![Great Bay Temple](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/key_rings/great_bay_temple.png?raw=true)

Whether or not the Great Bay Temple keys are on a key ring.


![Stone Tower Temple](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/key_rings/stone_tower_temple.png?raw=true)

Whether or not the Stone Tower Temple keys are on a key ring.

<br />

### Silver Rupee Pouches

---

![Silver Rupee Pouches: Off](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/silver_rupee_pouches/off.png?raw=true)![Silver Rupee Pouches: Some](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/silver_rupee_pouches/some.png?raw=true)![Silver Rupee Pouches: All](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/silver_rupee_pouches/all.png?raw=true)

This setting quickly modifies all other settings on this tab. If this is set to "Off", all other options will be disabled and uninteractable. If this is set to "Some", all of the options will be freely modifiable. If this is set to "All", all of the options will be forcably turned on and uninteractable.

If you want all but one dungeon's silver rupee pouches active, you can set this to "All", then set it to "Some" to save you the work of manually enabling almost every silver rupee pouch.

---

![Dodongo's Cavern (MQ Only)](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/silver_rupee_pouches/dodongos_cavern.png?raw=true)

Whether or not the Dodongo's Cavern silver rupees are in pouches.

This dungeon only has silver rupees in Master Quest.


![Ice Cavern (Vanilla Only)](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/silver_rupee_pouches/ice_cavern.png?raw=true)

Whether or not the Ice Cavern silver rupees are in pouches.

This dungeon only has silver rupees in Vanilla.


![Bottom of the Well (Vanilla Only)](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/silver_rupee_pouches/bottom_of_the_well.png?raw=true)

Whether or not the Bottom of the Well silver rupees are in pouches.

This dungeon only has silver rupees in Vanilla.

---

![Gerudo Training Ground](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/silver_rupee_pouches/gerudo_training_ground.png?raw=true)

Whether or not the Gerudo Training Ground silver rupees are in pouches.


![Spirit Temple](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/silver_rupee_pouches/spirit_temple.png?raw=true)

Whether or not the Spirit Temple silver rupees are in pouches.


![Shadow Temple](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/silver_rupee_pouches/shadow_temple.png?raw=true)

Whether or not the Shadow Temple silver rupees are in pouches.


![Ganon's Castle](https://github.com/ariahks/ootmmrando_ariahks/blob/main/images/settings/silver_rupee_pouches/ganons_castle.png?raw=true)

Whether or not the Ganon's Castle silver rupees are in pouches.

<br />

## To-Do List

There are a number of ways that I would like to improve this tracker over time, but I can't promise any kind of consistency in updates. That said, here are some of the things I'd theoretically like to add given infinite time.

- Better support for dungeon reward shuffle.
- Individually configurable silver rupee pouches.
- Both an "Unshared Items" variant and an "Unshared Items w/ Souls" variant.
- Map Tracker??? (long shot)

I may add or remove stuff from this list at any time.

Also, new randomizer features that affect shared items will take priority.

Shared Beans? Shared Scarecrow Songs? Please?? 👀👀
