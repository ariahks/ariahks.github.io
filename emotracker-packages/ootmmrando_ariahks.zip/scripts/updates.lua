function tracker_on_accessibility_updated() 
    update_configurables()
    update_capacity_upgrades()
    update_dungeon_things()
end