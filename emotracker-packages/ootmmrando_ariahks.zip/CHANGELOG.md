# Releases

## v2.0.0

With this release comes a rewrite from the ground up behind the scenes!

- Saving & Loading works now! In previous versions, there was a bug that wouldn't allow you to load a saved state. Loading takes a little while, but rest assured it's working!
- Better dungeon reward system! On the surface it looks the same, but now when noting where dungeon rewards are located, it will skip over any rewards already accounted for, significantly reducing tedium.

### Visuals
- Stray fairy textures and text on owl statues, some souls, and some settings redone.
- Key ring and silver rupee pouch settings are now easier to parse.

### Layout
- Bottles are now shared! The tracker now tracks each of the six bottles separately.
- Settings have been rearranged, in-so-doing birthed a new tab: "Misc. Settings".

### Settings
- Added the "Transcendent Fairy" setting to add the transcendent fairy to the tracker.
- Added the "Note Shuffle" setting to track songs note by note.
- Added the "Bombchus" setting to specify how bombchus should be tracked: as a simple toggle, with the bomb bags, or as its own progressive item.
- Added the "Bronze Scale" setting to track the bronze scale progressively with the silver and golden scales.
- Added the "Pre-Planted Beans (OoT)" setting to hide OoT's magic beans from the tracker.
- Added the "Random Bottle Contents" setting to remove the default contents from four of the shared bottles, and allow you to track their contents yourself.


## v1.2.0

- Added the "Scarecrow Songs" option to toggle whether or not each games' Scarecrow Songs should be trackable.
- Reordered the Silver Rupees for Shadow Temple and Ganon's Castle to align with the order they have in the in-game tracker.

## v1.1.0

- Reorganized the settings menu (I think it's better).
- Separated the "Skip Child Zelda" and the "Open Kakariko Gate" option because I initially didn't realize the Chicken could exist when Zelda's Letter doesn't.
- Adjusted the amount of Water Temple keys from 6 to 5 to match how the randomizer handles them.
- Added a "Keysanity" option to correct the amount of Fire Temple keys exist, since there are 7 keys if they are all in the dungeon, and 8 otherwise.

## v1.0.0

Initial Release

An items only tracker for the Ocarina of Time x Majora's Mask combined randomizer with a focus on shared items, designed with the sole focus of being the tracker I myself use.

### Variants

Two variants currently exist, Shared Items and Shared Items w/ Souls. One day, I may add unshared variants too, but there is no current plan to implement that.

### Settings

While this tracker assumes as much is shared as is supported by the randomizer, there are a lot of settings you can mess with to determine which items you want to keep track of, like coins, triforce pieces, small keys, tingle maps, owl statues, eggs, c-buttons, and more!

There are even such quality of life features as auto key ring and silver rupee pouch support! Just set which rings and pouches you are using, and when you get one, one click will bring your key/silver rupee count up to max.

The modular design allows you to have any combination of these settings enabled at one time, and have all the items you didn't enable not be visible and in your way.
